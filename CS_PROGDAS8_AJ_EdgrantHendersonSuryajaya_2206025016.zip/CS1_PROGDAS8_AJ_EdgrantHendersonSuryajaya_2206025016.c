#include <stdio.h>

void update(int *x, int *y);//mencari penjumlahan dan pengurangan kuadrat 2 angka

int main(){
    int x, y; //x dan y sebagai input

    printf ("==================================================================\n"
            "| \n"
            "| Program mencari sum dan difference kuadrat 2 angka\n"
            "| \n"
            "==================================================================\n");

    printf ("************************Please Enter Input************************\n"
            "| \n"
            "| masukkan x: ");
    scanf ("%d", &x);
    printf ("| masukkan y: ");
    scanf ("%d", &y);
    printf ("| \n"
            "******************************************************************\n");

    update(&x, &y);//call by refference dengan memberi alamat x dan y

    printf ("===========================Output Program=========================\n"
            "| \n"
            "| x adalah: %d\n"
            "| y adalah: %d\n"
            "| \n"
            "==================================================================\n", x, y);
	
	return 0;
}

void update(int *x, int *y){
    int tempX;
    int tempY;

	//memastikan tempX lebih besar dari tempY agar pengurangan selalu positif
    if (*y > *x){
        tempX = *y;
        tempY = *x;
    }
    else{
        tempX = *x;
        tempY = *y;
    }

	//mengganti x menjadi penjumlahan kuadrat dan y menjadi pengurangan kuadrat
    *x = tempX*tempX + tempY*tempY;
    *y = tempX*tempX - tempY*tempY;
}